/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigo;

import java.util.ArrayList;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.PrintWriter;

/**
 *
 * @author user
 */
public class Usuario {
    private String auxContra;
    private ArrayList<String> usuario = new ArrayList<String>();
    private ArrayList<String> contrasena = new ArrayList<String>();

    public Usuario(String usuario,String contrasena) {
        this.usuario.add(usuario);
        this.contrasena.add(contrasena);
        File file = new File("Usuarios.txt");
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
            }
    public String getUsuario(int i) {
        return usuario.get(i);
    }

    public void setUsuario(String usuario) {
        this.usuario.add(usuario);
    }

    public String getContrasena(int i) {
        return contrasena.get(i);
    }
    public void setContrasena(String contrasena) {
        this.contrasena.add(contrasena);
    }
    public Boolean comprobarUsuario(String usuario){
     try{
         BufferedReader br=new BufferedReader(new FileReader("Usuarios.txt"));
         String aux;
         while((aux=br.readLine())!=null){
             String[] separacion=aux.split(",");
             if(separacion.length>0){
                 if(separacion[0].trim().equals(usuario)){
                     auxContra=separacion[1].trim();
                     return true;
                 }
             }
             
         }
     }catch(IOException ex){
         ex.printStackTrace();
     }
     return false;
    }
    public Boolean permitirAcceso(String contrasena){
        if(contrasena.equals(auxContra)){
            return true;
        }
        return false;
    }
    public void guardarUsuario(String usuario,String contrasena){
        try{
            FileWriter out=new FileWriter("Usuarios.txt",true);
            out.write(usuario+","+contrasena+"\n");
            out.close();
            }catch(Exception e){
                System.out.println(e.getMessage());
            }
        
    }
}
