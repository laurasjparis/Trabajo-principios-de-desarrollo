/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigo;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.PrintWriter;
import javax.swing.DefaultListModel;
import javax.swing.JList;

public class Tarea {
    private String nombre;
    private int hora;
    private int dia;
    private int prioridad;
    private String usuario;
    
    public Tarea(String nombre, int dia, int prioridad, int hora,String usuario){
        this.nombre=nombre;
        this.dia=dia;
        this.hora=hora;
        this.prioridad=prioridad;
        this.usuario=usuario;
        File file = new File("Tareas.txt");
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }}
public void guardarTarea(String nombre,int dia,int prioridad,int hora,String usuario){
    this.nombre=nombre;
        this.dia=dia;
        this.hora=hora;
        this.prioridad=prioridad;
        this.usuario=usuario;
        try{
            FileWriter out=new FileWriter("Tareas.txt",true);
            out.write(this.dia+"~"+this.hora+"~"+this.prioridad+"~"+this.usuario+"~"+this.nombre+"\n");
            out.close();
            }catch(Exception e){
                System.out.println(e.getMessage());
            }
            }
    public void ordenarFichero(){
        ArrayList<Integer> dias=new ArrayList<Integer>();
        ArrayList<Integer> horas=new ArrayList<Integer>();
        ArrayList<Integer> prioridades=new ArrayList<Integer>();
        ArrayList<String> nombres=new ArrayList<String>();
        ArrayList<String> usuarios=new ArrayList<String>();
        File file = new File("Tareas.txt");
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
             try{
         BufferedReader br=new BufferedReader(new FileReader("Tareas.txt"));
         String aux;
         while((aux=br.readLine())!=null){
             String[] separacion= aux.split("~");
             if(separacion.length>0){
                 dias.add( Integer.parseInt(separacion[0]));
                 horas.add( Integer.parseInt(separacion[1]));
                 prioridades.add(Integer.parseInt(separacion[2]));
                 usuarios.add(separacion[3]);
                 nombres.add(separacion[4]);
             }
         }
     }catch(IOException ex){
         ex.printStackTrace();
     }
        for (int i = 0; i < dias.size(); i++) {
            int j=i;
            while (j>0 && (dias.get(j-1)>dias.get(j))){
                int auxD=dias.get(j);
                int auxH=horas.get(j);
                int auxP=prioridades.get(j);
                String auxU=usuarios.get(j);
                String auxN=nombres.get(j);
                
                dias.set(j,dias.get(j-1));
                dias.set(j-1,auxD);
                
                horas.set(j,horas.get(j-1));
                horas.set(j-1,auxH);
                
                
                prioridades.set(j,prioridades.get(j-1));
                prioridades.set(j-1,auxP);
                
                usuarios.set(j,usuarios.get(j-1));
                usuarios.set(j-1,auxU);
                
                nombres.set(j,nombres.get(j-1));
                nombres.set(j-1,auxN);
                j--; 
        }}
    for (int i = 0; i < dias.size(); i++) {
    for (int j = 0; j < dias.size() - i - 1; j++) {

        if (dias.get(j).equals(dias.get(j + 1))) {
            int auxH;
            int auxP;
            String auxU;
            String auxN;
            
            if (horas.get(j).equals(horas.get(j + 1)) && prioridades.get(j) > prioridades.get(j + 1)) {

                auxP=prioridades.get(j);
                auxU=usuarios.get(j);
                auxN=nombres.get(j);
                
                
                
                prioridades.set(j, prioridades.get(j + 1));
                prioridades.set(j+1, auxP);
                
                usuarios.set(j,usuarios.get(j+1));
                usuarios.set(j+1,auxU);

                
                nombres.set(j, nombres.get(j + 1));
                nombres.set(j+1, auxN);
            }

            else if (horas.get(j) > horas.get(j + 1)) {
                auxH=horas.get(j);
                auxP=prioridades.get(j);
                auxU=usuarios.get(j);
                auxN=nombres.get(j);
                
                horas.set(j, horas.get(j + 1));
                horas.set(j+1, auxH);
                
                
                prioridades.set(j, prioridades.get(j + 1));
                prioridades.set(j+1, auxP);
                
                usuarios.set(j,usuarios.get(j+1));
                usuarios.set(j+1,auxU);

                
                nombres.set(j, nombres.get(j + 1));
                nombres.set(j+1, auxN);
                }
            }
        }
    }
try {
    BufferedWriter bw = new BufferedWriter(new FileWriter("Tareas.txt"));
    for (int i=0;i<dias.size();i++) {
        bw.write(dias.get(i)+"~"+horas.get(i)+"~"+prioridades.get(i)+"~"+usuarios.get(i)+"~"+ nombres.get(i));
        bw.newLine();
    }
    bw.close();
} catch (IOException ex) {
    ex.printStackTrace();
}
    }
public DefaultListModel mostrarTareas(String usuario){
    DefaultListModel modelo=new DefaultListModel();
    String[] dias={"LUNES","MARTES","MIERCOLES","JUEVES","VIERNES","SABADO","DOMINGO"};
    try{
         BufferedReader br=new BufferedReader(new FileReader("Tareas.txt"));
         String aux;
         while((aux=br.readLine())!=null){
             String[] separacion= aux.split("~");
             if(separacion.length>0){
                 if(usuario.equals(separacion[3])){
                     modelo.addElement(dias[Integer.parseInt(separacion[0])]+": "+separacion[4]+" a las "+separacion[1]+" con prioridad "+separacion[2]);
                 }
                 
             }
         }
     }catch(IOException ex){
         ex.printStackTrace();
     }
    return modelo;
}
public void eliminarTarea(int opc,String usu){
     ArrayList<Integer> dias=new ArrayList<Integer>();
        ArrayList<Integer> horas=new ArrayList<Integer>();
        ArrayList<Integer> prioridades=new ArrayList<Integer>();
        ArrayList<String> nombres=new ArrayList<String>();
        ArrayList<String> usuarios=new ArrayList<String>();
        File file = new File("Tareas.txt");
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
         try{
         BufferedReader br=new BufferedReader(new FileReader("Tareas.txt"));
         String aux;
         while((aux=br.readLine())!=null){
             String[] separacion= aux.split("~");
             if(separacion.length>0){
                 dias.add( Integer.parseInt(separacion[0]));
                 horas.add( Integer.parseInt(separacion[1]));
                 prioridades.add(Integer.parseInt(separacion[2]));
                 usuarios.add(separacion[3]);
                 nombres.add(separacion[4]);
             }
         }
         int auxU=0;
         for(int i=0;i<usuarios.size();i++){
         if(usuarios.get(i).equals(usu)){
             System.out.println(usuarios.get(0));
             System.out.println(usu+" "+usuarios.get(i));
             if(auxU==opc){
                dias.remove(i);
                horas.remove(i);
                prioridades.remove(i);
                usuarios.remove(i);
                nombres.remove(i);
                break;}
             else{
                 auxU++;
             }
         }
         
         }
         
             
    }catch (IOException ex) {
    ex.printStackTrace();
}
    try {
    BufferedWriter bw = new BufferedWriter(new FileWriter("Tareas.txt"));
    for (int i=0;i<dias.size();i++) {
        bw.write(dias.get(i)+"~"+horas.get(i)+"~"+prioridades.get(i)+"~"+usuarios.get(i)+"~"+ nombres.get(i));
        bw.newLine();
    }
    bw.close();
} catch (IOException ex) {
    ex.printStackTrace();
}
    }

}



   
    

